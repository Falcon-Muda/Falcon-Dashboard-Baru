import requests
from bs4 import BeautifulSoup
from datetime import datetime

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}


def get_soup(url: str):
    response = requests.get(url, headers=HEADERS, timeout=15)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def find_first(soup, selectors):
    """Coba berbagai selector, return yang pertama ketemu"""
    for tag, attrs in selectors:
        el = soup.find(tag, attrs)
        if el:
            return el.get_text(strip=True)
    return ""


def find_content(soup, selectors):
    """Cari div konten, return paragraf-paragrafnya"""
    for tag, attrs in selectors:
        el = soup.find(tag, attrs)
        if el:
            paragraphs = el.find_all("p")
            if paragraphs:
                return " ".join([p.get_text(strip=True) for p in paragraphs[:15]])
    # Fallback: ambil semua paragraf
    paragraphs = soup.find_all("p")
    return " ".join([p.get_text(strip=True) for p in paragraphs[:10]])


def scrape_news(url: str) -> dict:
    """Auto-detect sumber dan scrape artikel"""
    try:
        if "detik.com" in url:
            return scrape_detik(url)
        elif "kompas.com" in url:
            return scrape_kompas(url)
        elif "tribunnews.com" in url:
            return scrape_tribun(url)
        elif "cnnindonesia.com" in url:
            return scrape_cnn(url)
        elif "antaranews.com" in url:
            return scrape_antara(url)
        elif "tempo.co" in url:
            return scrape_tempo(url)
        else:
            return scrape_generic(url)
    except Exception as e:
        return {"success": False, "url": url, "error": str(e)}


def build_result(soup, url, source, title_selectors, date_selectors, author_selectors, content_selectors, tag_selectors=None):
    """Builder universal untuk semua scraper"""
    title = find_first(soup, title_selectors)
    date = find_first(soup, date_selectors)
    author = find_first(soup, author_selectors)
    content = find_content(soup, content_selectors)

    tags = []
    if tag_selectors:
        for tag, attrs in tag_selectors:
            elements = soup.find_all(tag, attrs)
            if elements:
                tags = [el.get_text(strip=True) for el in elements]
                break

    # Kalau judul masih kosong, fallback ke generic
    if not title:
        return scrape_generic(url)

    return {
        "success": True,
        "source": source,
        "url": url,
        "title": title,
        "author": author,
        "date": date,
        "content": content,
        "tags": tags,
        "scraped_at": datetime.now().isoformat()
    }


def scrape_detik(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "Detik.com",
        title_selectors=[
            ("h1", {"class": "detail__title"}),
            ("h1", {"class": "title"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("div", {"class": "detail__date"}),
            ("span", {"class": "date"}),
            ("time", {}),
        ],
        author_selectors=[
            ("div", {"class": "detail__author"}),
            ("span", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "detail__body-text"}),
            ("div", {"class": "detail__body"}),
            ("div", {"class": "content"}),
        ],
        tag_selectors=[
            ("a", {"class": "nav__tag"}),
            ("a", {"class": "tag"}),
        ]
    )


def scrape_kompas(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "Kompas.com",
        title_selectors=[
            ("h1", {"class": "read__title"}),
            ("h1", {"class": "title"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("div", {"class": "read__time"}),
            ("span", {"class": "date"}),
            ("time", {}),
        ],
        author_selectors=[
            ("div", {"class": "credit-title-name"}),
            ("span", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "read__content"}),
            ("div", {"class": "content"}),
            ("article", {}),
        ],
        tag_selectors=[
            ("a", {"class": "tag__article"}),
            ("a", {"class": "tag"}),
        ]
    )


def scrape_tribun(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "Tribunnews.com",
        title_selectors=[
            ("h1", {"id": "arttitle"}),
            ("h1", {"class": "title"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("time", {}),
            ("span", {"class": "date"}),
        ],
        author_selectors=[
            ("div", {"class": "side-article txt-article"}),
            ("span", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "side-article txt-article"}),
            ("div", {"class": "content"}),
            ("article", {}),
        ],
        tag_selectors=[
            ("a", {"class": "tag"}),
        ]
    )


def scrape_cnn(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "CNN Indonesia",
        title_selectors=[
            ("h1", {"class": "title"}),
            ("h1", {"class": "headline"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("div", {"class": "date"}),
            ("time", {}),
            ("span", {"class": "date"}),
        ],
        author_selectors=[
            ("div", {"class": "author"}),
            ("span", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "detail-text"}),
            ("div", {"class": "content"}),
            ("article", {}),
        ],
        tag_selectors=[
            ("a", {"class": "topic"}),
            ("a", {"class": "tag"}),
        ]
    )


def scrape_antara(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "Antara News",
        title_selectors=[
            ("h1", {"class": "post-title"}),
            ("h1", {"class": "title"}),
            ("h1", {"itemprop": "headline"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("span", {"class": "post-date"}),
            ("time", {}),
            ("span", {"class": "date"}),
            ("div", {"class": "date"}),
        ],
        author_selectors=[
            ("span", {"class": "post-author"}),
            ("span", {"class": "author"}),
            ("div", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "post-content"}),
            ("div", {"class": "article-content"}),
            ("div", {"class": "content"}),
            ("article", {}),
        ],
        tag_selectors=[
            ("a", {"rel": "tag"}),
            ("a", {"class": "tag"}),
        ]
    )


def scrape_tempo(url: str) -> dict:
    soup = get_soup(url)
    return build_result(
        soup, url, "Tempo.co",
        title_selectors=[
            ("h1", {"class": "title"}),
            ("h1", {"class": "headline"}),
            ("h1", {"data-testid": "title"}),
            ("h1", {}),
        ],
        date_selectors=[
            ("p", {"class": "date"}),
            ("time", {}),
            ("span", {"class": "date"}),
            ("div", {"class": "date"}),
        ],
        author_selectors=[
            ("p", {"class": "penulis"}),
            ("span", {"class": "author"}),
            ("div", {"class": "author"}),
        ],
        content_selectors=[
            ("div", {"class": "detail-konten"}),
            ("div", {"class": "article-content"}),
            ("div", {"class": "content"}),
            ("section", {"class": "main-content"}),
            ("article", {}),
        ],
        tag_selectors=[
            ("a", {"class": "tag-artikel"}),
            ("a", {"class": "tag"}),
        ]
    )


def scrape_generic(url: str) -> dict:
    """Fallback scraper untuk semua sumber"""
    try:
        soup = get_soup(url)

        title = soup.find("h1")
        title = title.get_text(strip=True) if title else ""

        date = soup.find("time")
        date = date.get_text(strip=True) if date else ""

        paragraphs = soup.find_all("p")
        content = " ".join([p.get_text(strip=True) for p in paragraphs[:10]])

        return {
            "success": True if title else False,
            "source": "Unknown",
            "url": url,
            "title": title,
            "author": "",
            "date": date,
            "content": content,
            "tags": [],
            "scraped_at": datetime.now().isoformat()
        }
    except Exception as e:
        return {"success": False, "source": "Unknown", "url": url, "error": str(e)}