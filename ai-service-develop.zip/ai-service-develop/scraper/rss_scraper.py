import feedparser
import schedule
import time
import requests
from datetime import datetime

# RSS Feed dari 6 media
RSS_FEEDS = {
    "Detik.com": [
        "https://news.detik.com/rss",
        "https://news.detik.com/indeks/rss",
    ],
    "Kompas.com": [
        "https://rss.kompas.com/nasional",
        "https://rss.kompas.com/regional",
    ],
    "Tribunnews.com": [
        "https://www.tribunnews.com/rss",
    ],
    "CNN Indonesia": [
        "https://www.cnnindonesia.com/rss",
    ],
    "Antara News": [
        "https://www.antaranews.com/rss/terkini.xml",
        "https://www.antaranews.com/rss/nasional.xml",
    ],
    "Tempo.co": [
        "https://rss.tempo.co/nasional",
        "https://rss.tempo.co/hukum",
    ],
}

AI_SERVICE_URL = "http://localhost:8001/analyze"

def fetch_rss(source: str, feed_url: str) -> list:
    """Ambil artikel terbaru dari RSS feed"""
    try:
        feed = feedparser.parse(feed_url)
        articles = []

        for entry in feed.entries[:5]:  # ambil 5 artikel terbaru per feed
            articles.append({
                "source": source,
                "title": entry.get("title", ""),
                "url": entry.get("link", ""),
                "published": entry.get("published", ""),
                "summary": entry.get("summary", "")
            })

        print(f"[{datetime.now().strftime('%H:%M:%S')}] ✅ {source}: {len(articles)} artikel ditemukan")
        return articles

    except Exception as e:
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ❌ {source} error: {str(e)}")
        return []


def analyze_article(article: dict) -> dict:
    """Kirim artikel ke AI service untuk dianalisis"""
    try:
        response = requests.post(
            AI_SERVICE_URL,
            params={"url": article["url"]},
            timeout=30
        )
        result = response.json()

        if result.get("success"):
            print(f"  📰 {article['title'][:60]}...")
            print(f"  🏷️  Kategori: {result['ai_analysis']['category']['primary']}")
            print(f"  📍 Lokasi: {', '.join(result['ai_analysis']['location'])}")
            print()

        return result

    except Exception as e:
        print(f"  ❌ Gagal analisis: {str(e)}")
        return {"success": False, "error": str(e)}


def run_scraper():
    """Jalankan scraper untuk semua sumber"""
    print(f"\n{'='*60}")
    print(f"🔍 Scraping dimulai: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")

    all_articles = []

    # Fetch semua RSS
    for source, feeds in RSS_FEEDS.items():
        for feed_url in feeds:
            articles = fetch_rss(source, feed_url)
            all_articles.extend(articles)

    print(f"\n📊 Total artikel ditemukan: {len(all_articles)}")
    print(f"🤖 Mulai analisis AI...\n")

    # Analisis setiap artikel
    results = []
    for article in all_articles[:10]:  # limit 10 artikel dulu untuk test
        result = analyze_article(article)
        results.append(result)

    print(f"\n✅ Selesai! {len([r for r in results if r.get('success')])} artikel berhasil dianalisis")
    return results


def start_scheduler(interval_minutes: int = 30):
    """Jalankan scraper otomatis setiap X menit"""
    print(f"🚀 Scheduler aktif - scraping setiap {interval_minutes} menit")
    print(f"⏰ Scraping pertama dimulai sekarang...\n")

    # Jalankan sekali dulu langsung
    run_scraper()

    # Schedule berikutnya
    schedule.every(interval_minutes).minutes.do(run_scraper)

    while True:
        schedule.run_pending()
        time.sleep(60)


if __name__ == "__main__":
    # Jalankan scraper sekali untuk test
    run_scraper()