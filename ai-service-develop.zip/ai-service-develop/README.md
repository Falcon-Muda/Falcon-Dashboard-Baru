# 🤖 OSINT AI Service

Python FastAPI microservice untuk scraping berita, klasifikasi IPOLEKSOSBUDHANKAM, ekstraksi lokasi, Prunckun scoring, dan actor tracking. Digunakan oleh platform-main via HTTP API.

---

## 🚀 Fitur

- **Scraper** — 6 media nasional (Detik, Kompas, Tribun, CNN, Antara, Tempo)
- **RSS Feed** — otomatis ambil artikel terbaru
- **Klasifikasi AI** — Claude API + keyword fallback
- **NER Lokasi** — ekstraksi 34 provinsi Indonesia
- **Prunckun Scoring** — M×C×O threat assessment
- **Actor Tracking** — ekstraksi pelaku/korban/fasilitator
- **Callsign Generator** — ID unik per artikel (CHM-YYYYMMDD-XXXX)
- **Source Credibility** — rating kredibilitas sumber

---

## 🛠️ Tech Stack

- **Framework**: FastAPI (Python 3.11)
- **NLP**: IndoBERT + keyword classifier
- **AI API**: Anthropic Claude (opsional)
- **Scraping**: BeautifulSoup4 + Requests
- **RSS**: Feedparser

---

## ⚙️ Requirements

- Python 3.11+
- pip

---

## 📦 Cara Install (Standalone)

### 1. Clone Repository
```bash
git clone https://github.com/Falcon-Muda/ai-service.git
cd ai-service
```

### 2. Buat Virtual Environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install fastapi uvicorn requests beautifulsoup4 feedparser schedule indoNLP scikit-learn pandas python-dotenv anthropic
```

### 4. Setup Environment

Buat file `.env`:
```env
ANTHROPIC_API_KEY=sk-ant-xxxxx  # opsional, untuk akurasi lebih tinggi
```

### 5. Jalankan Service
```bash
uvicorn main:app --reload --port=8001
```

Akses Swagger UI: **http://localhost:8001/docs**

---

## 🔌 API Endpoints

| Method | Endpoint | Fungsi |
|---|---|---|
| `GET` | `/` | Status service |
| `GET` | `/health` | Health check |
| `POST` | `/analyze?url=...` | Pipeline lengkap: scrape + klasifikasi + lokasi + prunckun + actor |
| `POST` | `/scrape?url=...` | Scrape artikel saja |
| `POST` | `/classify?text=...` | Klasifikasi teks saja |
| `GET` | `/rss?feed_url=...&limit=5` | Ambil artikel dari RSS feed |

---

## 📊 Contoh Response `/analyze`
```json
{
  "success": true,
  "callsign": "CHM-20260321-AB12",
  "source": "Detik.com",
  "source_credibility": 4,
  "title": "Judul artikel...",
  "ai_analysis": {
    "category": {
      "primary": "Hankam",
      "confidence": 0.95
    },
    "location": ["DKI Jakarta", "Jawa Barat"],
    "prunckun": {
      "motif": 3,
      "capability": 3,
      "opportunity": 3,
      "score": 21.6,
      "threat_level": 2,
      "media_exposure": "sedang"
    },
    "actors": [
      {"name": "Nama Pelaku", "role": "pelaku", "affiliation": "Institusi"}
    ],
    "victims_count": 0
  }
}
```

---

## 📰 Sumber Berita yang Didukung

| Media | Credibility | RSS |
|---|---|---|
| Antara News | ⭐⭐⭐⭐⭐ | ✅ |
| Kompas.com | ⭐⭐⭐⭐⭐ | ✅ |
| Tempo.co | ⭐⭐⭐⭐⭐ | ✅ |
| CNN Indonesia | ⭐⭐⭐⭐ | ✅ |
| Detik.com | ⭐⭐⭐⭐ | ✅ |
| Tribunnews.com | ⭐⭐⭐ | ✅ |

---

## 🔗 Repository Terkait

- **Platform Utama**: [Falcon-Muda/platform-main](https://github.com/Falcon-Muda/platform-main)

---

*Dibuat oleh komunitas Falcon Muda — Peduli Pertahanan dan Keamanan Indonesia* 🇮🇩