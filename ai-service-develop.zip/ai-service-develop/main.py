from fastapi import FastAPI
from scraper.scraper import scrape_news
from nlp.classifier import (
    classify_text, extract_location,
    generate_callsign, generate_title_hash,
    get_source_credibility, calculate_prunckun,
    extract_actors
)
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="OSINT AI Service", version="2.0.0")


@app.get("/")
def root():
    return {"status": "OSINT AI Service is running", "version": "2.0.0"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/scrape")
def scrape(url: str):
    """Scrape berita dari URL yang diberikan"""
    result = scrape_news(url)
    return result


@app.post("/classify")
def classify(text: str):
    """Klasifikasi teks ke kategori IPOLEKSOSBUDHANKAM"""
    category = classify_text(text)
    location = extract_location(text)
    return {
        "text": text,
        "category": category,
        "location": location
    }


@app.post("/analyze")
def analyze(url: str):
    """
    Pipeline lengkap:
    1. Scrape artikel dari URL
    2. Klasifikasi IPOLEKSOSBUDHANKAM
    3. Ekstrak lokasi
    4. Hitung Prunckun Score
    5. Generate callsign + title hash
    6. Source credibility rating
    """
     # Step 1: Scrape
    scraped = scrape_news(url)

    if not scraped["success"]:
        return {
            "success": False,
            "url": url,
            "error": scraped.get("error", "Scraping gagal")
        }

    # Step 2: Klasifikasi
    full_text = f"{scraped['title']} {scraped['content']}"
    category = classify_text(full_text)

    # Step 3: Ekstrak lokasi
    location = extract_location(full_text)

    # Step 4: Prunckun scoring
    prunckun = calculate_prunckun(
        scraped['title'],
        scraped['content'],
        category['primary']
    )

    # Step 5: Actor extraction
    actors_data = extract_actors(
        scraped['title'],
        scraped['content'],
        category['primary']
    )

    # Step 6: Callsign + title hash
    callsign = generate_callsign()
    title_hash = generate_title_hash(scraped['title'])

    # Step 7: Source credibility
    source_credibility = get_source_credibility(scraped['source'])

    return {
        "success": True,
        "callsign": callsign,
        "source": scraped["source"],
        "source_credibility": source_credibility,
        "url": url,
        "title": scraped["title"],
        "title_hash": title_hash,
        "author": scraped["author"],
        "date": scraped["date"],
        "tags": scraped["tags"],
        "content_preview": scraped["content"][:500] + "...",
        "scraped_at": scraped["scraped_at"],
        "ai_analysis": {
            "category": category,
            "location": location,
            "prunckun": prunckun,
            "actors": actors_data["actors"],
            "victims_count": actors_data["victims_count"],
        }
    }


@app.get("/rss")
def get_rss(feed_url: str, limit: int = 10):
    """Ambil daftar artikel dari RSS feed"""
    from scraper.rss_scraper import fetch_rss

    source = "Unknown"
    if "detik" in feed_url: source = "Detik.com"  # noqa: E701
    elif "kompas" in feed_url: source = "Kompas.com" # noqa: E701
    elif "tribun" in feed_url: source = "Tribunnews.com" # noqa: E701
    elif "cnnindonesia" in feed_url: source = "CNN Indonesia" # noqa: E701
    elif "antara" in feed_url: source = "Antara News" # noqa: E701
    elif "tempo" in feed_url: source = "Tempo.co" # noqa: E701

    articles = fetch_rss(source, feed_url)
    return {"articles": articles[:limit]}