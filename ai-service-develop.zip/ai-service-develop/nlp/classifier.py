import re
import os
import anthropic
import hashlib
import random
import string
from datetime import datetime

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

PROVINCES = {
    "Aceh": ["aceh", "banda aceh", "nanggroe aceh"],
    "Sumatera Utara": ["sumatera utara", "sumut", "medan"],
    "Sumatera Barat": ["sumatera barat", "sumbar", "padang", "bukittinggi"],
    "Riau": ["riau", "pekanbaru", "dumai"],
    "Kepulauan Riau": ["kepri", "kepulauan riau", "batam", "tanjungpinang"],
    "Jambi": ["jambi"],
    "Sumatera Selatan": ["sumatera selatan", "sumsel", "palembang"],
    "Bangka Belitung": ["bangka belitung", "babel", "pangkalpinang"],
    "Bengkulu": ["bengkulu"],
    "Lampung": ["lampung", "bandar lampung"],
    "DKI Jakarta": ["jakarta", "dki", "ibu kota", "ibukota", "jakarta pusat",
                    "jakarta selatan", "jakarta utara", "jakarta barat", "jakarta timur"],
    "Jawa Barat": ["jawa barat", "jabar", "bandung", "bogor", "depok",
                   "bekasi", "cimahi", "sukabumi", "cirebon", "tasikmalaya"],
    "Banten": ["banten", "tangerang", "serang", "cilegon"],
    "Jawa Tengah": ["jawa tengah", "jateng", "semarang", "solo", "surakarta",
                    "salatiga", "pekalongan", "tegal", "magelang"],
    "DI Yogyakarta": ["yogyakarta", "jogja", "diy", "sleman", "bantul", "gunung kidul"],
    "Jawa Timur": ["jawa timur", "jatim", "surabaya", "malang", "kediri",
                   "blitar", "madiun", "mojokerto", "pasuruan", "probolinggo"],
    "Bali": ["bali", "denpasar", "singaraja", "gianyar", "tabanan"],
    "Nusa Tenggara Barat": ["ntb", "nusa tenggara barat", "mataram", "lombok"],
    "Nusa Tenggara Timur": ["ntt", "nusa tenggara timur", "kupang", "flores", "timor"],
    "Kalimantan Barat": ["kalimantan barat", "kalbar", "pontianak", "singkawang"],
    "Kalimantan Tengah": ["kalimantan tengah", "kalteng", "palangkaraya"],
    "Kalimantan Selatan": ["kalimantan selatan", "kalsel", "banjarmasin", "banjarbaru"],
    "Kalimantan Timur": ["kalimantan timur", "kaltim", "samarinda", "balikpapan", "bontang"],
    "Kalimantan Utara": ["kalimantan utara", "kaltara", "tarakan", "nunukan"],
    "Sulawesi Utara": ["sulawesi utara", "sulut", "manado", "bitung", "tomohon"],
    "Sulawesi Tengah": ["sulawesi tengah", "sulteng", "palu", "donggala"],
    "Sulawesi Selatan": ["sulawesi selatan", "sulsel", "makassar", "parepare", "palopo"],
    "Sulawesi Tenggara": ["sulawesi tenggara", "sultra", "kendari", "baubau"],
    "Gorontalo": ["gorontalo"],
    "Sulawesi Barat": ["sulawesi barat", "sulbar", "mamuju"],
    "Maluku": ["maluku", "ambon", "tual"],
    "Maluku Utara": ["maluku utara", "malut", "ternate", "tidore"],
    "Papua Barat": ["papua barat", "manokwari", "sorong"],
    "Papua": ["papua", "jayapura", "merauke", "timika", "nabire"],
}


def classify_text(text: str) -> dict:
    """Klasifikasi teks menggunakan Claude API"""
    try:
        prompt = f"""Kamu adalah sistem klasifikasi berita Indonesia untuk platform monitoring keamanan nasional.

Klasifikasikan teks berita berikut ke dalam SATU kategori IPOLEKSOSBUDHANKAM yang paling sesuai:

- Ideologi: radikalisme, ekstremisme, terorisme, separatisme, propaganda anti-Pancasila, intoleransi agama
- Politik: pemilu, pilkada, kebijakan pemerintah, partai politik, korupsi pejabat, demonstrasi politik
- Ekonomi: inflasi, harga pangan, investasi, perdagangan, PHK, kemiskinan, korupsi keuangan
- Sosial: konflik masyarakat, kriminalitas, pembunuhan, penganiayaan, narkoba, miras, kecelakaan massal, bencana sosial
- Budaya: adat istiadat, kesenian, warisan budaya, kearifan lokal, festival daerah
- Hankam: TNI, Polri, pertahanan negara, keamanan wilayah, operasi militer, perbatasan, terorisme bersenjata

PENTING:
- Kriminalitas (pembunuhan, penganiayaan, narkoba, miras) = SOSIAL
- Mudik/transportasi/infrastruktur = SOSIAL
- Korupsi pejabat = POLITIK
- Bencana alam = SOSIAL
- Operasi militer/TNI/Polri = HANKAM

Teks: {text[:1000]}

Jawab HANYA dengan format JSON berikut tanpa penjelasan tambahan:
{{"primary": "NamaKategori", "confidence": 0.95, "reason": "alasan singkat"}}"""

        message = client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}]
        )

        import json
        response_text = message.content[0].text.strip()
        result = json.loads(response_text)

        return {
            "primary": result.get("primary", "Sosial"),
            "confidence": result.get("confidence", 0.8),
            "reason": result.get("reason", ""),
            "scores": {}
        }

    except Exception as e:
        print(f"Claude API error: {e}, falling back to keyword classifier")
        return classify_text_fallback(text)


def classify_text_fallback(text: str) -> dict:
    """Fallback ke keyword classifier jika Claude API gagal"""
    KEYWORDS = {
        "Ideologi": [
            "radikalisme", "ekstremisme", "terorisme", "ideologi", "intoleransi",
            "separatisme", "propaganda", "anti pancasila", "khilafah", "jihad",
            "penistaan agama", "provokasi agama", "fanatisme"
        ],
        "Politik": [
            "pemilu", "pilkada", "pilpres", "kebijakan", "partai", "presiden",
            "gubernur", "bupati", "walikota", "dpr", "dprd", "korupsi pejabat",
            "anggaran", "apbn", "apbd", "legislatif", "kabinet", "menteri",
            "oposisi", "koalisi", "kampanye", "suara", "calon"
        ],
        "Ekonomi": [
            "inflasi", "harga pangan", "investasi", "perdagangan", "phk",
            "upah minimum", "ekspor", "impor", "rupiah", "saham", "pajak",
            "subsidi", "kemiskinan", "pengangguran", "bisnis", "pasar modal",
            "bank", "kurs", "bbm", "tarif listrik"
        ],
        "Sosial": [
            "pembunuhan", "penganiayaan", "penebasan", "penikaman", "penggelapan",
            "pencurian", "perampokan", "pemerkosaan", "kekerasan", "kriminal",
            "narkoba", "miras", "minuman keras", "pesta miras", "overdosis",
            "mudik", "lebaran", "natal", "kecelakaan", "banjir", "gempa",
            "kebakaran", "bencana", "longsor", "konflik warga", "tawuran",
            "demo", "unjuk rasa", "kemacetan", "transportasi umum"
        ],
        "Budaya": [
            "budaya", "adat", "tradisi", "seni", "warisan", "festival",
            "suku", "kebudayaan", "museum", "bahasa daerah", "kesenian",
            "tarian", "batik", "wayang", "kuliner daerah"
        ],
        "Hankam": [
            "tni", "polri", "militer", "pertahanan", "operasi militer",
            "perbatasan", "senjata api", "penembakan oleh aparat",
            "bom", "serangan teroris", "intel", "densus 88",
            "pasukan", "pangdam", "kapolda", "keamanan nasional",
            "ancaman negara", "sabotase"
        ]
    }

    text_lower = text.lower()
    scores = {}
    for category, keywords in KEYWORDS.items():
        score = sum(1 for k in keywords if k in text_lower)
        scores[category] = score

    primary = max(scores, key=scores.get) if max(scores.values()) > 0 else "Sosial"
    return {"primary": primary, "confidence": 0.6, "reason": "keyword fallback", "scores": scores}


def extract_location(text: str) -> list:
    text_lower = text.lower()
    found = {}

    for province, keywords in PROVINCES.items():
        for keyword in keywords:
            pattern = r'\b' + re.escape(keyword) + r'\b'
            if re.search(pattern, text_lower):
                if province not in found:
                    found[province] = 0
                found[province] += 1
                break

    if not found:
        return ["Tidak Diketahui"]

    sorted_locations = sorted(found.keys(), key=lambda x: found[x], reverse=True)
    return sorted_locations


def generate_callsign() -> str:
    """Generate ID unik per artikel format CHM-YYYYMMDD-XXXX"""
    date = datetime.now().strftime('%Y%m%d')
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"CHM-{date}-{random_part}"


def generate_title_hash(title: str) -> str:
    """Generate hash dari judul untuk deteksi duplikat"""
    cleaned = title.lower().strip()
    return hashlib.md5(cleaned.encode()).hexdigest()[:16]


def get_source_credibility(source: str) -> int:
    """Rating kredibilitas sumber 1-5"""
    credibility_map = {
        "Antara News": 5,
        "Kompas.com": 5,
        "Tempo.co": 5,
        "CNN Indonesia": 4,
        "Detik.com": 4,
        "Tribunnews.com": 3,
    }
    return credibility_map.get(source, 3)


def calculate_prunckun(title: str, content: str, category: str) -> dict:
    """Hitung Prunckun Score: Motif × Capability × Opportunity"""
    text = f"{title} {content[:500]}".lower()

    high_keywords = ['tewas', 'korban', 'serangan', 'ledakan', 'darurat',
                     'kritis', 'hancur', 'invasi', 'perang', 'krisis']
    med_keywords = ['meningkat', 'eskalasi', 'terancam', 'potensi',
                    'terdeteksi', 'mencurigakan', 'waspadai', 'konflik']
    low_keywords = ['aman', 'kondusif', 'damai', 'stabil', 'normal']

    is_high = any(k in text for k in high_keywords)
    is_med = any(k in text for k in med_keywords)
    is_low = any(k in text for k in low_keywords)

    base_scores = {
        'Hankam': 3, 'Ideologi': 3, 'Politik': 2,
        'Sosial': 2, 'Ekonomi': 2, 'Budaya': 1,
    }
    base = base_scores.get(category, 2)

    adj = 2 if is_high else (1 if is_med else 0)
    adj_neg = -1 if is_low else 0

    motif = min(5, max(1, base + adj + adj_neg))
    capability = min(5, max(1, base))
    opportunity = min(5, max(1, base + (1 if is_med else 0)))

    score = round((motif * capability * opportunity) / 125 * 100, 1)

    if score >= 81:     threat_level = 5  # noqa: E701
    elif score >= 61:   threat_level = 4  # noqa: E701
    elif score >= 36:   threat_level = 3  # noqa: E701
    elif score >= 16:   threat_level = 2  # noqa: E701
    else:               threat_level = 1  # noqa: E701

    media_exposure = 'tinggi' if is_high else ('sedang' if is_med else 'rendah')

    return {
        'motif': motif,
        'capability': capability,
        'opportunity': opportunity,
        'score': score,
        'threat_level': threat_level,
        'media_exposure': media_exposure,
    }

def extract_actors(title: str, content: str, category: str) -> dict:
    """
    Ekstrak aktor dari artikel menggunakan Claude API
    Returns: {actors: [{name, role, affiliation}], victims_count: int}
    """
    try:
        text = f"{title}\n\n{content[:800]}"

        prompt = f"""Kamu adalah sistem ekstraksi informasi intelijen dari berita Indonesia.

Dari teks berita berikut, ekstrak:
1. Aktor yang terlibat (pelaku, korban, fasilitator, pengamat)
2. Jumlah korban/terdampak (angka, 0 jika tidak ada)

Format aktor:
- pelaku: orang/kelompok yang melakukan tindakan
- korban: orang/kelompok yang menjadi sasaran
- fasilitator: orang/kelompok yang membantu/memfasilitasi
- pengamat: pejabat/tokoh yang berkomentar

Teks: {text}

Jawab HANYA dengan JSON berikut tanpa penjelasan:
{{
  "actors": [
    {{"name": "nama aktor", "role": "pelaku|korban|fasilitator|pengamat", "affiliation": "institusi/kelompok atau kosong"}}
  ],
  "victims_count": 0
}}

Catatan:
- Maksimal 5 aktor paling relevan
- Jika tidak ada aktor jelas, kembalikan actors: []
- victims_count adalah jumlah orang terdampak/korban (angka integer)"""

        message = client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}]
        )

        import json
        response_text = message.content[0].text.strip()
        result = json.loads(response_text)

        return {
            "actors": result.get("actors", []),
            "victims_count": result.get("victims_count", 0)
        }

    except Exception as e:
        print(f"Actor extraction error: {e}, using fallback")
        return extract_actors_fallback(title, content)


def extract_actors_fallback(title: str, content: str) -> dict:
    """Fallback ekstraksi aktor berbasis keyword"""
    text = f"{title} {content[:500]}".lower()

    victims_keywords = ['korban', 'tewas', 'meninggal', 'luka', 'terdampak', 'warga']
    victims_count = 0

    import re
    # Cari angka sebelum keyword korban
    for keyword in victims_keywords:
        matches = re.findall(r'(\d+)\s*(?:orang\s*)?' + keyword, text)
        if matches:
            victims_count = max(victims_count, max(int(m) for m in matches))

    return {
        "actors": [],
        "victims_count": victims_count
    }